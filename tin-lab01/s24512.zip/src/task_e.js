var condition_true = true;
var condition_false = false;

if(condition_true){
    console.log(condition_true);
}

if(!condition_false){
    console.log(condition_true);
}
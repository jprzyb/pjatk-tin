function mainFunction(x){
    console.log("What a sick number? Wonder how it get there... " +x);
}

function sum(x,y){
    return x+y;
}

function multiply(x,y){
    return x*y;
}

function divide(x,y){
    return x/y;
}
mainFunction(sum(1,2))
mainFunction(multiply(1,2))
mainFunction(divide(1,2))
package pl.pjatk.s24512.groovy.models

class CampaignCreation {
    Long campId
    Long creaId

    @Override
    public String toString() {
        return "CampaignCreation{" +
                "campId=" + campId +
                ", creaId=" + creaId +
                '}';
    }
}

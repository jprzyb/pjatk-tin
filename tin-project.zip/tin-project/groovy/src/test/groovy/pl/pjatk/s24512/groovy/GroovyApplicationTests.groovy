package pl.pjatk.s24512.groovy

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class GroovyApplicationTests {

    @Test
    void contextLoads() {
    }

}
